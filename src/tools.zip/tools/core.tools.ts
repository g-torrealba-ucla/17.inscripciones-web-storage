export enum opcionFicha {
  add = 'add',
  edit = 'edit',
  delete = 'delete'
}
